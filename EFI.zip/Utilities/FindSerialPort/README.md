FindSerialPort
================

This script finds PCIe serial ports and outputs their paths. Thanks [joevt](https://github.com/joevt) for writing it.
